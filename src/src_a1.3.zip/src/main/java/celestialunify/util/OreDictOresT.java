
package celestialunify.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import celestialunify.block.*;

import celestialunify.ElementsCelestialUnifyMod;

@ElementsCelestialUnifyMod.ModElement.Tag
public class OreDictOresT extends ElementsCelestialUnifyMod.ModElement {
	public OreDictOresT(ElementsCelestialUnifyMod instance) {
		super(instance, 7);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreNickel", new ItemStack(BlockK22bkeplerNickelOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockK22bkeplerIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockK22bkeplerDiamondOre.block, (int) (1)));

		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockK10DiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockK10IronOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockK10DiamondOre2.block, (int) (1)));
		OreDictionary.registerOre("oreCobalt", new ItemStack(BlockK10CobaltOre.block, (int) (1)));
		OreDictionary.registerOre("oreAluminium", new ItemStack(BlockK10AluminiumOre.block, (int) (1)));

		OreDictionary.registerOre("oreCoal", new ItemStack(BlockK452DeepCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockK452DeepIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreGold", new ItemStack(BlockK452DeepGoldOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockK452DeepDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreNickel", new ItemStack(BlockK452DeepNickelOre.block, (int) (1)));

		OreDictionary.registerOre("oreCopper", new ItemStack(BlockK442bCopperOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockK442bIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreNickel", new ItemStack(BlockK442bNickelOre.block, (int) (1)));
		OreDictionary.registerOre("oreGold", new ItemStack(BlockK442bGoldOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockK442bDiamondOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSArielCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSArielDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSArielSubsurfaceCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSArielSubsurfaceDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSArielSurfaceCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSArielSurfaceDiamondOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSCharonIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSCharonMeteoriteIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSCharonSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSCharonSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSCharonSurfaceMeteoriteIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSCharonSurfaceSiliconOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreDesh", new ItemStack(BlockSSDeimosDeshOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSDeimosIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSDeimosMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSDeimosSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSDeimosSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSDioneIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSDioneMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSDioneSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSDioneSubsurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSDioneSubsurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSDioneSubsurfaceSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSDioneSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSDioneSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSIapetusDarkSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSIapetusDarkSurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSIapetusDarkSurfaceSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSIapetusDarkSurfaceDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSIapetusIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSIapetusMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSIapetusSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSIapetusLightSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSIapetusLightSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSMimasCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSMimasDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSMimasEmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreSapphire", new ItemStack(BlockSSMimasSapphireOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSOberonIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSOberonMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSOberonSubsurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSOberonSubsurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSOberonSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSOberonSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSProteusIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSProteusMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSProteusSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSProteusSubsurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSProteusSubsurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSProteusSubsurfaceSiliconOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSProteusSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSProteusSurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreSilicon", new ItemStack(BlockSSProteusSurfaceSiliconOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSTethysIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSTethysCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSTethysDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSTethysMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSTethysSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreCoal", new ItemStack(BlockSSTethysSurfaceCoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSTethysSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSRheaIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSRheaMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSRheaDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSRheaSubsurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSRheaSubsurfaceMeteoricIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSRheaSubsurfaceDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockSSRheaSurfaceIronOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockSSRheaSurfaceMeteoricIronOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSTitaniaEmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreSapphire", new ItemStack(BlockSSTitaniaSapphireOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSTitaniaSubsurfaceEmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreSapphire", new ItemStack(BlockSSTitaniaSubsurfaceSapphireOre.block, (int) (1)));
		
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSUmbrielDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSUmbrielEmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSUmbrielSubsurfaceDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSUmbrielSubsurfaceEmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockSSUmbrielSurfaceDiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockSSUmbrielSurfaceEmeraldOre.block, (int) (1)));

		OreDictionary.registerOre("oreCoal", new ItemStack(BlockTrap1CoalOre.block, (int) (1)));
		OreDictionary.registerOre("oreIron", new ItemStack(BlockTrap1IronOre.block, (int) (1)));
		OreDictionary.registerOre("oreGold", new ItemStack(BlockTrap1GoldOre.block, (int) (1)));
		OreDictionary.registerOre("oreEmerald", new ItemStack(BlockTrap1EmeraldOre.block, (int) (1)));
		OreDictionary.registerOre("oreDiamond", new ItemStack(BlockTrap1DiamondOre.block, (int) (1)));
		OreDictionary.registerOre("oreMeteoricIron", new ItemStack(BlockTrap1MeteoricOre.block, (int) (1)));

	}
}
