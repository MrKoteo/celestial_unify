
package celestialunify.util;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import celestialunify.ElementsCelestialUnifyMod;

@ElementsCelestialUnifyMod.ModElement.Tag
public class OreDictOtherTags extends ElementsCelestialUnifyMod.ModElement {
	public OreDictOtherTags(ElementsCelestialUnifyMod instance) {
		super(instance, 9);
	}

	@Override
	public void init(FMLInitializationEvent event) {
	}
}
