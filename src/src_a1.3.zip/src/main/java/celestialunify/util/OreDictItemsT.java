
package celestialunify.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import celestialunify.item.ItemNickelIngot;

import celestialunify.ElementsCelestialUnifyMod;

@ElementsCelestialUnifyMod.ModElement.Tag
public class OreDictItemsT extends ElementsCelestialUnifyMod.ModElement {
	public OreDictItemsT(ElementsCelestialUnifyMod instance) {
		super(instance, 8);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("ingotNickel", new ItemStack(ItemNickelIngot.block, (int) (1)));
	}
}
