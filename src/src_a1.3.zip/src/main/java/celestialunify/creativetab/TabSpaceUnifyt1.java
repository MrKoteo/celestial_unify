
package celestialunify.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import net.minecraft.creativetab.CreativeTabs;

import celestialunify.ElementsCelestialUnifyMod;

@ElementsCelestialUnifyMod.ModElement.Tag
public class TabSpaceUnifyt1 extends ElementsCelestialUnifyMod.ModElement {
	public TabSpaceUnifyt1(ElementsCelestialUnifyMod instance) {
		super(instance, 195);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabspace_unifyt_1") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(Items.END_CRYSTAL, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static CreativeTabs tab;
}
