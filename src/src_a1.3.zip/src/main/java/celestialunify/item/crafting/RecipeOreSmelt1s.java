package celestialunify.item.crafting;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.OreDictionary;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;
import celestialunify.item.ItemNickelIngot;


import celestialunify.block.*;
import celestialunify.ElementsCelestialUnifyMod;

import java.util.List;

@ElementsCelestialUnifyMod.ModElement.Tag
public class RecipeOreSmelt1s extends ElementsCelestialUnifyMod.ModElement {
    public RecipeOreSmelt1s(ElementsCelestialUnifyMod instance) {
        super(instance, 11);
    }

	@Override
	public void init(FMLInitializationEvent event) {
	    registerSmelting("oreNickel", "ingotNickel", 1, 1F);
	    registerSmelting("oreIron", "ingotIron", 1, 1F);
	    registerSmelting("oreDiamond", "gemDiamond", 1, 2F);
	    registerSmelting("oreCobalt", "ingotCobalt", 1, 1F);
	    registerSmelting("oreGold", "ingotGold", 1, 1F);
	    registerSmelting("oreSilicon", "gemSilicon", 1, 1F);
	    registerSmelting("oreEmerald", "gemEmerald", 1, 1F);
	    
	}
	
	private boolean isSpecialCase(String oreName) {
	    return oreName.equals("oreNickel") ||
	           oreName.equals("oreIron") ||
	           oreName.equals("oreDiamond") ||
	           oreName.equals("oreCobalt") ||
	           oreName.equals("oreGold") ||
	           oreName.equals("oreSilicon") ||
	           oreName.equals("oreEmerald");
	}
	
	private void autoRegisterSmelting(String inputOreDict) {
	    String material = inputOreDict.substring(3);
	    
	    for (String prefix : new String[]{"ingot", "gem", "dust", "nugget"}) {
	        String outputTag = prefix + material;
	        if (!OreDictionary.getOres(outputTag).isEmpty()) {
	            registerSmelting(inputOreDict, outputTag, 1, 1.0F);
	            return;
	        }
	    }
	    
	    registerSmelting(inputOreDict, "ingotIron", 1, 0.7F);
	    System.out.println("[OreSmelt] Used fallback for: " + inputOreDict);
	}
	
	private void registerSmelting(String inputOreDict, String outputOreDict, int outputCount, float experience) {
	    List<ItemStack> inputs = OreDictionary.getOres(inputOreDict);
	    List<ItemStack> outputs = OreDictionary.getOres(outputOreDict);
	    
	    if (inputs.isEmpty()) {
	        System.out.println("[OreSmelt] No inputs for: " + inputOreDict);
	        return;
	    }
	    
	    ItemStack outputStack;
	    if (!outputs.isEmpty()) {
	        outputStack = outputs.get(0).copy();
	        outputStack.setCount(outputCount);
	    } else {
	        outputStack = new ItemStack(Items.IRON_INGOT, outputCount);
	        System.out.println("[OreSmelt] No outputs for: " + outputOreDict + ", using iron ingot");
	    }
	    
	    for (ItemStack input : inputs) {
	        GameRegistry.addSmelting(input, outputStack, experience);
	    }
	}
}